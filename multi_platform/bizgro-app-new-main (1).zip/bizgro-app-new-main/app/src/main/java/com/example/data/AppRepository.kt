package com.example.data

import kotlinx.coroutines.flow.Flow
import java.util.UUID

class AppRepository(private val appDao: AppDao) {

    // --- UnitBisnis ---
    val allUnits: Flow<List<UnitBisnis>> = appDao.getAllUnits()

    suspend fun insertUnit(unit: UnitBisnis): Long = appDao.insertUnit(unit)

    suspend fun deleteUnit(id: Int) = appDao.deleteUnit(id)

    suspend fun getUnitById(id: Int): UnitBisnis? = appDao.getUnitById(id)

    // --- Products ---
    fun getProductsByUnit(unitId: Int): Flow<List<Product>> = appDao.getProductsByUnit(unitId)

    suspend fun getProductsByUnitSync(unitId: Int): List<Product> = appDao.getProductsByUnitSync(unitId)

    suspend fun insertProduct(product: Product) = appDao.insertProduct(product)

    suspend fun deleteProduct(id: String) = appDao.deleteProduct(id)

    suspend fun updateProductStock(productId: String, newStock: Int) = appDao.updateProductStock(productId, newStock)

    // --- Product Variants ---
    fun getVariantsByProduct(productId: String): Flow<List<ProductVariant>> = appDao.getVariantsByProduct(productId)

    suspend fun insertVariant(variant: ProductVariant) = appDao.insertVariant(variant)

    // --- Employees ---
    fun getEmployeesByUnit(unitId: Int): Flow<List<Employee>> = appDao.getEmployeesByUnit(unitId)

    suspend fun getEmployeesByUnitSync(unitId: Int): List<Employee> = appDao.getEmployeesByUnitSync(unitId)

    suspend fun insertEmployee(employee: Employee) = appDao.insertEmployee(employee)

    suspend fun deleteEmployee(id: Int) = appDao.deleteEmployee(id)

    suspend fun getEmployeeByPin(unitId: Int, pin: String): Employee? = appDao.getEmployeeByPin(unitId, pin)

    // --- Transactions ---
    fun getTransactionsByUnit(unitId: Int): Flow<List<Transaction>> = appDao.getTransactionsByUnit(unitId)

    suspend fun insertTransaction(transaction: Transaction) {
        appDao.insertTransaction(transaction)
        // Log action
        logAction(
            unitId = transaction.unitId,
            pesan = "Transaksi baru ditambahkan: ${transaction.kategoriTrx} sebesar Rp ${String.format("%,.0f", transaction.nominal)}",
            tipe = "SUCCESS",
            kategori = "FINANCE"
        )
    }

    suspend fun deleteTransaction(id: Int, unitId: Int) {
        appDao.deleteTransaction(id)
        logAction(
            unitId = unitId,
            pesan = "Transaksi dihapus",
            tipe = "WARNING",
            kategori = "FINANCE"
        )
    }

    // --- Stock Logs ---
    fun getStockLogsByUnit(unitId: Int): Flow<List<StockLog>> = appDao.getStockLogsByUnit(unitId)

    suspend fun insertStockLog(log: StockLog) = appDao.insertStockLog(log)

    // --- POS Customers ---
    fun getCustomersByUnit(unitId: Int): Flow<List<PosCustomer>> = appDao.getCustomersByUnit(unitId)

    suspend fun insertCustomer(customer: PosCustomer) = appDao.insertCustomer(customer)

    // --- POS Orders & Order Items ---
    fun getOrdersByUnit(unitId: Int): Flow<List<PosOrder>> = appDao.getOrdersByUnit(unitId)

    suspend fun processPosOrder(
        order: PosOrder,
        items: List<PosOrderItem>
    ) {
        // Insert order
        appDao.insertOrder(order)

        // Insert items and adjust stock
        for (item in items) {
            appDao.insertOrderItem(item)

            // Get product to adjust stock
            val product = appDao.getProductById(item.productId)
            if (product != null) {
                val oldStock = product.stok
                val newStock = (oldStock - item.qty).coerceAtLeast(0)
                appDao.updateProductStock(product.id, newStock)

                // Log stock change
                val stockLog = StockLog(
                    id = UUID.randomUUID().toString(),
                    productId = product.id,
                    productName = product.nama,
                    unitId = order.unitId,
                    stokAwal = oldStock,
                    perubahan = -item.qty,
                    stokAkhir = newStock,
                    alasan = "POS",
                    tanggal = System.currentTimeMillis()
                )
                appDao.insertStockLog(stockLog)
            }
        }

        // Add to transactions (Financials)
        val transaction = Transaction(
            unitId = order.unitId,
            kategoriTrx = "MASUK",
            nominal = order.total,
            tanggal = order.tanggal,
            keterangan = "Penjualan POS #${order.orderNumber}"
        )
        appDao.insertTransaction(transaction)

        // Log action
        logAction(
            unitId = order.unitId,
            pesan = "Penjualan POS selesai #${order.orderNumber}. Total: Rp ${String.format("%,.0f", order.total)}",
            tipe = "SUCCESS",
            kategori = "POS"
        )
    }

    fun getOrderItems(orderId: String): Flow<List<PosOrderItem>> = appDao.getOrderItems(orderId)

    // --- Attendance ---
    fun getAttendanceByUnit(unitId: Int): Flow<List<Attendance>> = appDao.getAttendanceByUnit(unitId)

    suspend fun checkInEmployee(employeeId: Int, employeeName: String, unitId: Int, dateStr: String, timeStr: String) {
        val existing = appDao.getAttendanceForEmployeeToday(employeeId, dateStr)
        if (existing == null) {
            val attendance = Attendance(
                employeeId = employeeId,
                date = dateStr,
                checkIn = timeStr,
                checkOut = null,
                status = "HADIR"
            )
            appDao.insertAttendance(attendance)
            logAction(
                unitId = unitId,
                pesan = "Karyawan $employeeName melakukan Check-In pukul $timeStr",
                tipe = "INFO",
                kategori = "HR"
            )
        }
    }

    suspend fun checkOutEmployee(employeeId: Int, employeeName: String, unitId: Int, dateStr: String, timeStr: String) {
        val existing = appDao.getAttendanceForEmployeeToday(employeeId, dateStr)
        if (existing != null && existing.checkOut == null) {
            val updated = existing.copy(checkOut = timeStr)
            appDao.insertAttendance(updated)
            logAction(
                unitId = unitId,
                pesan = "Karyawan $employeeName melakukan Check-Out pukul $timeStr",
                tipe = "INFO",
                kategori = "HR"
            )
        }
    }

    // --- Payroll ---
    fun getPayrollByUnit(unitId: Int): Flow<List<Payroll>> = appDao.getPayrollByUnit(unitId)

    suspend fun processPayroll(payroll: Payroll, employeeName: String, unitId: Int) {
        appDao.insertPayroll(payroll)

        // Record as financial expense
        val expense = Transaction(
            unitId = unitId,
            kategoriTrx = "KELUAR",
            nominal = payroll.netSalary,
            tanggal = System.currentTimeMillis(),
            keterangan = "Gaji Karyawan: $employeeName (${payroll.monthYear})"
        )
        appDao.insertTransaction(expense)

        logAction(
            unitId = unitId,
            pesan = "Penggajian diproses untuk $employeeName (${payroll.monthYear}) sebesar Rp ${String.format("%,.0f", payroll.netSalary)}",
            tipe = "SUCCESS",
            kategori = "HR"
        )
    }

    // --- CRM ---
    fun getDealsByUnit(unitId: Int): Flow<List<CrmDeal>> = appDao.getDealsByUnit(unitId)

    suspend fun insertDeal(deal: CrmDeal) {
        appDao.insertDeal(deal)
        logAction(
            unitId = deal.unitId,
            pesan = "Pipeline Deal baru ditambahkan: ${deal.contactName} - Rp ${String.format("%,.0f", deal.dealValue)}",
            tipe = "INFO",
            kategori = "CRM"
        )
    }

    suspend fun updateDealStage(dealId: Int, stage: String, contactName: String, value: Double, unitId: Int) {
        appDao.updateDealStage(dealId, stage)
        logAction(
            unitId = unitId,
            pesan = "Deal $contactName (Rp ${String.format("%,.0f", value)}) diperbarui ke tahap: $stage",
            tipe = if (stage == "WON") "SUCCESS" else "INFO",
            kategori = "CRM"
        )
    }

    suspend fun deleteDeal(id: Int, unitId: Int) {
        appDao.deleteDeal(id)
        logAction(
            unitId = unitId,
            pesan = "Deal dihapus",
            tipe = "WARNING",
            kategori = "CRM"
        )
    }

    // --- Audit Trail ---
    fun getRiwayatAksiByUnit(unitId: Int): Flow<List<RiwayatAksi>> = appDao.getRiwayatAksiByUnit(unitId)

    suspend fun logAction(unitId: Int, pesan: String, tipe: String, kategori: String) {
        val action = RiwayatAksi(
            unitId = unitId,
            pesan = pesan,
            tipe = tipe,
            waktu = System.currentTimeMillis(),
            kategori = kategori
        )
        appDao.insertRiwayatAksi(action)
    }

    // --- Seeding ---
    suspend fun seedDatabaseIfEmpty() {
        val currentUnits = appDao.getProductsByUnitSync(1) // Checking database content indirectly or unit list
        // Let's get units first to see if any exist
        val dbState = appDao.getProductsByUnitSync(1) // Wait, if we check allUnits, since it returns a flow we can check sync data.
        // Let's perform a simple check. If no products are in the DB, we can insert our dummy unit and default data.
        val dummyProducts = appDao.getProductsByUnitSync(1)
        if (dummyProducts.isEmpty()) {
            // Seed a default unit
            val unitId = appDao.insertUnit(
                UnitBisnis(
                    id = 1,
                    namaUnit = "Sinar Baru Mart",
                    slug = "sinar-baru-mart",
                    alamat = "Jl. Merdeka No. 45, Jakarta",
                    modalAwal = 50000000.0,
                    kategori = "Ritel & Kelontong"
                )
            ).toInt()

            // Seed second unit (e.g. cabang)
            appDao.insertUnit(
                UnitBisnis(
                    id = 2,
                    namaUnit = "Sinar Baru Mart (Cabang Bandung)",
                    slug = "sinar-baru-bandung",
                    alamat = "Jl. Dago No. 12, Bandung",
                    modalAwal = 25000000.0,
                    kategori = "Ritel & Kelontong"
                )
            )

            // Seed Products
            val p1Id = UUID.randomUUID().toString()
            val p2Id = UUID.randomUUID().toString()
            val p3Id = UUID.randomUUID().toString()
            val p4Id = UUID.randomUUID().toString()

            appDao.insertProduct(Product(p1Id, "PRD001", "Kopi Robusta Lampung 250g", 22000.0, 35000.0, 150, "Bahan Makanan", unitId))
            appDao.insertProduct(Product(p2Id, "PRD002", "Beras Pandan Wangi 5kg", 68000.0, 85000.0, 40, "Bahan Pokok", unitId))
            appDao.insertProduct(Product(p3Id, "PRD003", "Minyak Goreng Filma 2L", 31000.0, 38500.0, 65, "Bahan Pokok", unitId))
            appDao.insertProduct(Product(p4Id, "PRD004", "Gula Pasir Gulaku 1kg", 13500.0, 17500.0, 110, "Bahan Pokok", unitId))

            // Seed variants
            appDao.insertVariant(ProductVariant(UUID.randomUUID().toString(), p1Id, "Bubuk Halus", "PRD001-F", 22000.0, 35000.0, 75))
            appDao.insertVariant(ProductVariant(UUID.randomUUID().toString(), p1Id, "Biji Kopi", "PRD001-B", 22000.0, 35000.0, 75))

            // Seed Employees
            appDao.insertEmployee(Employee(1, "Fandi Ahmad", "Kasir Senior", 3500000.0, "1234", "Staff", unitId))
            appDao.insertEmployee(Employee(2, "Siti Rahma", "Staf Gudang", 3200000.0, "4321", "Staff", unitId))
            appDao.insertEmployee(Employee(3, "Budi Santoso", "Store Manager", 5500000.0, "9999", "Manager", unitId))

            // Seed Transactions
            appDao.insertTransaction(Transaction(0, unitId, "MASUK", 15000000.0, System.currentTimeMillis() - 5 * 24 * 3600 * 1000, "Suntikan Modal Tambahan"))
            appDao.insertTransaction(Transaction(0, unitId, "KELUAR", 2400000.0, System.currentTimeMillis() - 4 * 24 * 3600 * 1000, "Restock Produk PRD001"))
            appDao.insertTransaction(Transaction(0, unitId, "MASUK", 425000.0, System.currentTimeMillis() - 3 * 24 * 3600 * 1000, "Penjualan Grosir"))
            appDao.insertTransaction(Transaction(0, unitId, "KELUAR", 850000.0, System.currentTimeMillis() - 2 * 24 * 3600 * 1000, "Sewa Listrik & Air"))
            appDao.insertTransaction(Transaction(0, unitId, "MASUK", 890000.0, System.currentTimeMillis() - 1 * 24 * 3600 * 1000, "Penjualan POS Harian"))

            // Seed POS Customers
            appDao.insertCustomer(PosCustomer(0, unitId, "Andi Setiawan", "andi@gmail.com", "08123456789"))
            appDao.insertCustomer(PosCustomer(0, unitId, "Dewi Lestari", "dewi@gmail.com", "08765432100"))

            // Seed CRM Deals
            appDao.insertDeal(CrmDeal(0, "Subhan Lubis", "Lubis Kopi Grosir", 12500000.0, "NEGOTIATION", "08521112233", unitId))
            appDao.insertDeal(CrmDeal(0, "Rina Melati", "Hotel Melati Bandung", 24000000.0, "PROSPECT", "08139998887", unitId))
            appDao.insertDeal(CrmDeal(0, "Hendra Jaya", "Resto Hendra", 8500000.0, "WON", "08112223334", unitId))

            // Seed stock logs
            appDao.insertStockLog(StockLog(UUID.randomUUID().toString(), p1Id, "Kopi Robusta Lampung 250g", unitId, 100, 50, 150, "RESTOCK", System.currentTimeMillis() - 4 * 24 * 3600 * 1000))

            // Seed Audit Trail
            logAction(unitId, "Sistem diinisialisasi dengan data default", "INFO", "SYSTEM")
            logAction(unitId, "Unit bisnis Sinar Baru Mart berhasil dibuat", "SUCCESS", "SYSTEM")
        }
    }
}
