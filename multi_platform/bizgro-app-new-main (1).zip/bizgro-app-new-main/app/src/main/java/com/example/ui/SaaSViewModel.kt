package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.GeminiService
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

sealed class Screen {
    object Dashboard : Screen()
    object Products : Screen()
    object POS : Screen()
    object HR : Screen()
    object CRM : Screen()
    object Portal : Screen()
    object Settings : Screen()
    object AIChat : Screen()
    object Supplier : Screen()
}

data class ChatMessage(
    val sender: String, // "USER" or "AI"
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class Supplier(
    val id: String,
    val name: String,
    val contactName: String,
    val phone: String,
    val email: String,
    val category: String,
    val address: String
)

data class PurchaseOrder(
    val id: String,
    val poNumber: String,
    val supplierId: String,
    val supplierName: String,
    val productName: String,
    val productId: String,
    val qty: Int,
    val unitCost: Double,
    val totalAmount: Double,
    val date: Long,
    val status: String // "DRAFT", "SENT", "RECEIVED"
)

data class BiMetrics(
    val totalMasuk: Double = 0.0,
    val totalKeluar: Double = 0.0,
    val netProfit: Double = 0.0,
    val margin: Double = 0.0,
    val efficiency: Double = 0.0,
    val cashRunway: Double = 0.0,
    val integrityScore: Int = 5,
    val outlook: String = "MODERATE",
    val riskAssessment: String = "LOW",
    val aiConfidence: Int = 45
)

class SaaSViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = AppRepository(db.appDao())

    // --- Active Screen State ---
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Dashboard)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    // --- Global Authentication State ---
    private val _isUserLoggedIn = MutableStateFlow<Boolean>(false)
    val isUserLoggedIn: StateFlow<Boolean> = _isUserLoggedIn.asStateFlow()

    private val _loggedInUserRole = MutableStateFlow<String>("") // "OWNER" or "STAFF"
    val loggedInUserRole: StateFlow<String> = _loggedInUserRole.asStateFlow()

    private val _loggedInUserEmail = MutableStateFlow<String>("")
    val loggedInUserEmail: StateFlow<String> = _loggedInUserEmail.asStateFlow()

    fun loginUser(email: String, pinOrPass: String, role: String): Boolean {
        if (role == "OWNER") {
            if ((email == "owner@nusantara.com" || email == "admin@nusantara.com" || email.trim().isEmpty()) && pinOrPass == "admin123") {
                _isUserLoggedIn.value = true
                _loggedInUserRole.value = "OWNER"
                _loggedInUserEmail.value = if (email.trim().isEmpty()) "owner@nusantara.com" else email
                _currentScreen.value = Screen.Dashboard
                return true
            }
        } else {
            // Staff login
            if ((email == "staff@nusantara.com" || email.trim().isEmpty()) && pinOrPass == "staff123") {
                _isUserLoggedIn.value = true
                _loggedInUserRole.value = "STAFF"
                _loggedInUserEmail.value = if (email.trim().isEmpty()) "staff@nusantara.com" else email
                _currentScreen.value = Screen.Portal
                return true
            }
            // Fallback: match by Pin from the DB employee records
            val employee = employees.value.find { it.pin == pinOrPass }
            if (employee != null) {
                _isUserLoggedIn.value = true
                _loggedInUserRole.value = "STAFF"
                _loggedInUserEmail.value = "${employee.fullName.lowercase().replace(" ", "")}@nusantara.com"
                _loggedStaffEmployee.value = employee
                _currentScreen.value = Screen.Portal
                return true
            }
        }
        return false
    }

    fun logoutUser() {
        _isUserLoggedIn.value = false
        _loggedInUserRole.value = ""
        _loggedInUserEmail.value = ""
        logoutStaff()
        _currentScreen.value = Screen.Dashboard
    }

    private val _themeMode = MutableStateFlow<String>("SYSTEM")
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    fun setThemeMode(mode: String) {
        _themeMode.value = mode
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    // --- Selected Unit State ---
    private val _selectedUnitId = MutableStateFlow<Int>(1)
    val selectedUnitId: StateFlow<Int> = _selectedUnitId.asStateFlow()

    val allUnits: StateFlow<List<UnitBisnis>> = repository.allUnits
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeUnit: StateFlow<UnitBisnis?> = combine(allUnits, _selectedUnitId) { units, selectedId ->
        units.find { it.id == selectedId }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun switchUnit(id: Int) {
        _selectedUnitId.value = id
        // Reset Cart and Staff Portal when switching units
        clearCart()
        logoutStaff()
    }

    // --- Dynamic Data Streams ---
    val products: StateFlow<List<Product>> = _selectedUnitId
        .flatMapLatest { unitId -> repository.getProductsByUnit(unitId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transactions: StateFlow<List<Transaction>> = _selectedUnitId
        .flatMapLatest { unitId -> repository.getTransactionsByUnit(unitId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val employees: StateFlow<List<Employee>> = _selectedUnitId
        .flatMapLatest { unitId -> repository.getEmployeesByUnit(unitId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val stockLogs: StateFlow<List<StockLog>> = _selectedUnitId
        .flatMapLatest { unitId -> repository.getStockLogsByUnit(unitId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val posCustomers: StateFlow<List<PosCustomer>> = _selectedUnitId
        .flatMapLatest { unitId -> repository.getCustomersByUnit(unitId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val posOrders: StateFlow<List<PosOrder>> = _selectedUnitId
        .flatMapLatest { unitId -> repository.getOrdersByUnit(unitId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val attendance: StateFlow<List<Attendance>> = _selectedUnitId
        .flatMapLatest { unitId -> repository.getAttendanceByUnit(unitId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val payroll: StateFlow<List<Payroll>> = _selectedUnitId
        .flatMapLatest { unitId -> repository.getPayrollByUnit(unitId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val crmDeals: StateFlow<List<CrmDeal>> = _selectedUnitId
        .flatMapLatest { unitId -> repository.getDealsByUnit(unitId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val riwayatAksi: StateFlow<List<RiwayatAksi>> = _selectedUnitId
        .flatMapLatest { unitId -> repository.getRiwayatAksiByUnit(unitId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Strategic Business Intelligence (BI) Engine ---
    val biMetrics: StateFlow<BiMetrics> = combine(transactions, activeUnit) { txList, unit ->
        val totalMasuk = txList.filter { it.kategoriTrx == "MASUK" }.sumOf { it.nominal }
        val totalKeluar = txList.filter { it.kategoriTrx == "KELUAR" }.sumOf { it.nominal }
        val netProfit = totalMasuk - totalKeluar
        val modalAwal = unit?.modalAwal ?: 10000000.0

        val margin = if (totalMasuk > 0) (netProfit / totalMasuk * 100) else 0.0
        val efficiency = if (totalMasuk > 0) (totalKeluar / totalMasuk * 100) else 0.0
        
        // Calculate Cash Runway
        val runwayMonths = if (totalKeluar > 0) (modalAwal / (totalKeluar / 3.0).coerceAtLeast(100000.0)) else 99.0

        // Calculate Integrity Score
        var score = when {
            margin > 30.0 -> 9
            margin > 15.0 -> 7
            margin > 0.0 -> 5
            else -> 3
        }
        if (efficiency < 40.0) score += 1
        if (efficiency > 80.0) score -= 1
        score = score.coerceIn(1, 10)

        val outlook = when {
            netProfit > 5000000.0 -> "STABLE"
            netProfit > 0.0 -> "MODERATE"
            else -> "CRITICAL WATCH"
        }

        val riskAssessment = when {
            runwayMonths < 3.0 -> "HIGH"
            runwayMonths < 6.0 -> "MEDIUM"
            else -> "LOW"
        }

        val confidence = (45 + (txList.size * 3)).coerceAtMost(95)

        BiMetrics(
            totalMasuk = totalMasuk,
            totalKeluar = totalKeluar,
            netProfit = netProfit,
            margin = margin,
            efficiency = efficiency,
            cashRunway = runwayMonths,
            integrityScore = score,
            outlook = outlook,
            riskAssessment = riskAssessment,
            aiConfidence = confidence
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BiMetrics())

    // --- POS Cart Operations ---
    private val _cart = MutableStateFlow<Map<Product, Int>>(emptyMap())
    val cart: StateFlow<Map<Product, Int>> = _cart.asStateFlow()

    fun addToCart(product: Product) {
        val currentQty = _cart.value[product] ?: 0
        if (currentQty < product.stok) {
            val updated = _cart.value.toMutableMap()
            updated[product] = currentQty + 1
            _cart.value = updated
        }
    }

    fun removeFromCart(product: Product) {
        val currentQty = _cart.value[product] ?: 0
        if (currentQty > 0) {
            val updated = _cart.value.toMutableMap()
            if (currentQty == 1) {
                updated.remove(product)
            } else {
                updated[product] = currentQty - 1
            }
            _cart.value = updated
        }
    }

    fun clearCart() {
        _cart.value = emptyMap()
    }

    fun checkoutCart(paymentMethod: String, customerId: Int?) {
        val cartItems = _cart.value
        if (cartItems.isEmpty()) return

        viewModelScope.launch {
            val orderId = UUID.randomUUID().toString()
            val orderNum = "POS-" + System.currentTimeMillis().toString().takeLast(6)
            val subtotal = cartItems.entries.sumOf { it.key.hargaJual * it.value }
            val total = subtotal // Simple direct total

            val order = PosOrder(
                id = orderId,
                orderNumber = orderNum,
                unitId = _selectedUnitId.value,
                customerId = customerId,
                subtotal = subtotal,
                total = total,
                paymentMethod = paymentMethod,
                status = "COMPLETED",
                tanggal = System.currentTimeMillis()
            )

            val orderItemsList = cartItems.map { (prod, qty) ->
                PosOrderItem(
                    id = UUID.randomUUID().toString(),
                    orderId = orderId,
                    productId = prod.id,
                    productName = prod.nama,
                    qty = qty,
                    price = prod.hargaJual
                )
            }

            repository.processPosOrder(order, orderItemsList)
            clearCart()
        }
    }

    // --- Staff Portal Dual Auth System ---
    private val _loggedStaffEmployee = MutableStateFlow<Employee?>(null)
    val loggedStaffEmployee: StateFlow<Employee?> = _loggedStaffEmployee.asStateFlow()

    private val _staffAuthError = MutableStateFlow<String?>(null)
    val staffAuthError: StateFlow<String?> = _staffAuthError.asStateFlow()

    fun loginStaff(pin: String) {
        viewModelScope.launch {
            _staffAuthError.value = null
            val employee = repository.getEmployeeByPin(_selectedUnitId.value, pin)
            if (employee != null) {
                _loggedStaffEmployee.value = employee
                repository.logAction(
                    unitId = _selectedUnitId.value,
                    pesan = "Staff ${employee.fullName} login ke Portal Karyawan",
                    tipe = "INFO",
                    kategori = "HR"
                )
            } else {
                _staffAuthError.value = "PIN tidak valid atau salah!"
            }
        }
    }

    fun logoutStaff() {
        _loggedStaffEmployee.value = null
        _staffAuthError.value = null
    }

    // --- AI Assistant Business Advisor ---
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = "AI",
                message = "Halo! Saya Asisten AI Bisnis Anda. Saya dapat membantu menganalisis kinerja keuangan, stok produk, efisiensi karyawan, atau pipeline CRM Anda. Ada yang bisa saya bantu hari ini?"
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isAiLoading = MutableStateFlow<Boolean>(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    fun sendMessageToAi(msg: String) {
        if (msg.trim().isEmpty()) return
        val userMsg = ChatMessage(sender = "USER", message = msg)
        _chatMessages.value = _chatMessages.value + userMsg

        viewModelScope.launch {
            _isAiLoading.value = true
            // Grab snapshot states of DB tables for prompt context builder
            val unit = activeUnit.value
            val currentProducts = products.value
            val currentTransactions = transactions.value
            val currentEmployees = employees.value
            val currentDeals = crmDeals.value
            val currentHistory = riwayatAksi.value

            val aiResponseStr = GeminiService.chatWithBusinessContext(
                userMessage = msg,
                unit = unit,
                products = currentProducts,
                transactions = currentTransactions,
                employees = currentEmployees,
                deals = currentDeals,
                history = currentHistory
            )

            val aiMsg = ChatMessage(sender = "AI", message = aiResponseStr)
            _chatMessages.value = _chatMessages.value + aiMsg
            _isAiLoading.value = false
        }
    }

    // --- Operations ---
    fun addUnit(name: String, alamat: String, modal: Double, kategori: String) {
        viewModelScope.launch {
            val slug = name.lowercase().replace(" ", "-")
            repository.insertUnit(
                UnitBisnis(
                    namaUnit = name,
                    slug = slug,
                    alamat = alamat,
                    modalAwal = modal,
                    kategori = kategori
                )
            )
        }
    }

    fun deleteUnit(id: Int) {
        viewModelScope.launch {
            repository.deleteUnit(id)
            if (_selectedUnitId.value == id) {
                // Try to find another unit or default to 1
                val remain = allUnits.value.firstOrNull { it.id != id }
                _selectedUnitId.value = remain?.id ?: 1
            }
        }
    }

    fun deleteTransaction(id: Int, unitId: Int) {
        viewModelScope.launch {
            repository.deleteTransaction(id, unitId)
        }
    }

    fun addProduct(sku: String, name: String, hargaBeli: Double, hargaJual: Double, stok: Int, kategori: String) {
        viewModelScope.launch {
            repository.insertProduct(
                Product(
                    id = UUID.randomUUID().toString(),
                    sku = sku,
                    nama = name,
                    hargaBeli = hargaBeli,
                    hargaJual = hargaJual,
                    stok = stok,
                    kategori = kategori,
                    unitId = _selectedUnitId.value
                )
            )
            repository.logAction(
                unitId = _selectedUnitId.value,
                pesan = "Produk baru dibuat: $name ($sku). Stok awal: $stok",
                tipe = "SUCCESS",
                kategori = "INVENTORY"
            )
        }
    }

    fun addEmployee(name: String, position: String, salary: Double, pin: String, role: String) {
        viewModelScope.launch {
            repository.insertEmployee(
                Employee(
                    fullName = name,
                    position = position,
                    salary = salary,
                    pin = pin,
                    role = role,
                    unitId = _selectedUnitId.value
                )
            )
            repository.logAction(
                unitId = _selectedUnitId.value,
                pesan = "Karyawan baru terdaftar: $name sebagai $position",
                tipe = "SUCCESS",
                kategori = "HR"
            )
        }
    }

    fun deleteEmployee(id: Int, name: String) {
        viewModelScope.launch {
            repository.deleteEmployee(id)
            repository.logAction(
                unitId = _selectedUnitId.value,
                pesan = "Karyawan $name dinonaktifkan",
                tipe = "WARNING",
                kategori = "HR"
            )
        }
    }

    fun deleteProduct(id: String, name: String) {
        viewModelScope.launch {
            repository.deleteProduct(id)
            repository.logAction(
                unitId = _selectedUnitId.value,
                pesan = "Produk $name dihapus dari katalog",
                tipe = "WARNING",
                kategori = "INVENTORY"
            )
        }
    }

    fun bulkRestockAll() {
        viewModelScope.launch {
            products.value.forEach { prod ->
                repository.updateProductStock(prod.id, 100)
            }
            repository.logAction(
                unitId = _selectedUnitId.value,
                pesan = "Restok massal dilakukan. Semua produk diatur ke 100 unit.",
                tipe = "SUCCESS",
                kategori = "INVENTORY"
            )
        }
    }

    fun logCrmFollowUp(company: String, contact: String) {
        viewModelScope.launch {
            repository.logAction(
                unitId = _selectedUnitId.value,
                pesan = "Simulasi WA Follow-up terkirim ke $contact ($company)",
                tipe = "SUCCESS",
                kategori = "CRM"
            )
        }
    }

    // --- Suppliers & Purchase Orders (SCM) Module ---
    private val _suppliers = MutableStateFlow<List<Supplier>>(emptyList())
    val suppliers: StateFlow<List<Supplier>> = _suppliers.asStateFlow()

    private val _purchaseOrders = MutableStateFlow<List<PurchaseOrder>>(emptyList())
    val purchaseOrders: StateFlow<List<PurchaseOrder>> = _purchaseOrders.asStateFlow()

    fun addSupplier(name: String, contact: String, phone: String, email: String, category: String, address: String) {
        val newList = _suppliers.value.toMutableList()
        newList.add(Supplier(
            id = UUID.randomUUID().toString(),
            name = name,
            contactName = contact,
            phone = phone,
            email = email,
            category = category,
            address = address
        ))
        _suppliers.value = newList
        viewModelScope.launch {
            repository.logAction(
                unitId = _selectedUnitId.value,
                pesan = "Supplier Baru Terdaftar: $name",
                tipe = "SUCCESS",
                kategori = "INVENTORY"
            )
        }
    }

    fun deleteSupplier(id: String, name: String) {
        _suppliers.value = _suppliers.value.filter { it.id != id }
        viewModelScope.launch {
            repository.logAction(
                unitId = _selectedUnitId.value,
                pesan = "Supplier Dihapus: $name",
                tipe = "WARNING",
                kategori = "INVENTORY"
            )
        }
    }

    fun createPurchaseOrder(supplierId: String, supplierName: String, productId: String, productName: String, qty: Int, unitCost: Double) {
        val poNum = "PO-" + System.currentTimeMillis().toString().takeLast(6)
        val newList = _purchaseOrders.value.toMutableList()
        val total = qty * unitCost
        val newPo = PurchaseOrder(
            id = UUID.randomUUID().toString(),
            poNumber = poNum,
            supplierId = supplierId,
            supplierName = supplierName,
            productId = productId,
            productName = productName,
            qty = qty,
            unitCost = unitCost,
            totalAmount = total,
            date = System.currentTimeMillis(),
            status = "DRAFT"
        )
        newList.add(newPo)
        _purchaseOrders.value = newList
        viewModelScope.launch {
            repository.logAction(
                unitId = _selectedUnitId.value,
                pesan = "PO Baru Dibuat: $poNum untuk $productName ($qty unit)",
                tipe = "INFO",
                kategori = "INVENTORY"
            )
        }
    }

    fun updatePoStatus(poId: String, newStatus: String) {
        val newList = _purchaseOrders.value.map { po ->
            if (po.id == poId) {
                val updatedPo = po.copy(status = newStatus)
                if (newStatus == "RECEIVED") {
                    viewModelScope.launch {
                        val currentProducts = products.value
                        val prod = currentProducts.find { it.id == po.productId }
                        if (prod != null) {
                            val newStock = prod.stok + po.qty
                            repository.updateProductStock(po.productId, newStock)
                            repository.insertStockLog(
                                StockLog(
                                    id = UUID.randomUUID().toString(),
                                    productId = po.productId,
                                    productName = po.productName,
                                    unitId = _selectedUnitId.value,
                                    stokAwal = prod.stok,
                                    perubahan = po.qty,
                                    stokAkhir = newStock,
                                    alasan = "RESTOCK",
                                    tanggal = System.currentTimeMillis()
                                )
                            )
                            repository.insertTransaction(
                                Transaction(
                                    unitId = _selectedUnitId.value,
                                    nominal = po.totalAmount,
                                    kategoriTrx = "KELUAR",
                                    keterangan = "Pembelian Bahan Baku PO ${po.poNumber} dari ${po.supplierName}",
                                    tanggal = System.currentTimeMillis()
                                )
                            )
                            repository.logAction(
                                unitId = _selectedUnitId.value,
                                pesan = "PO ${po.poNumber} DITERIMA. Stok ${po.productName} bertambah +${po.qty} unit. Pengeluaran dicatat: Rp ${String.format("%,.0f", po.totalAmount)}",
                                tipe = "SUCCESS",
                                kategori = "INVENTORY"
                            )
                        }
                    }
                } else if (newStatus == "SENT") {
                    viewModelScope.launch {
                        repository.logAction(
                            unitId = _selectedUnitId.value,
                            pesan = "PO ${po.poNumber} dikirim ke supplier ${po.supplierName}",
                            tipe = "INFO",
                            kategori = "INVENTORY"
                        )
                    }
                }
                updatedPo
            } else {
                po
            }
        }
        _purchaseOrders.value = newList
    }

    fun addTransaction(kategoriTrx: String, nominal: Double, keterangan: String) {
        viewModelScope.launch {
            repository.insertTransaction(
                Transaction(
                    unitId = _selectedUnitId.value,
                    kategoriTrx = kategoriTrx,
                    nominal = nominal,
                    tanggal = System.currentTimeMillis(),
                    keterangan = keterangan
                )
            )
        }
    }

    fun checkInStaffPortal() {
        val staff = _loggedStaffEmployee.value ?: return
        val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        viewModelScope.launch {
            repository.checkInEmployee(staff.id, staff.fullName, _selectedUnitId.value, dateStr, timeStr)
        }
    }

    fun checkOutStaffPortal() {
        val staff = _loggedStaffEmployee.value ?: return
        val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        viewModelScope.launch {
            repository.checkOutEmployee(staff.id, staff.fullName, _selectedUnitId.value, dateStr, timeStr)
        }
    }

    fun addDeal(contact: String, company: String, valDouble: Double, phone: String) {
        viewModelScope.launch {
            repository.insertDeal(
                CrmDeal(
                    contactName = contact,
                    companyName = company,
                    dealValue = valDouble,
                    stage = "PROSPECT",
                    phone = phone,
                    unitId = _selectedUnitId.value
                )
            )
        }
    }

    fun updateDealStage(dealId: Int, contact: String, value: Double, nextStage: String) {
        viewModelScope.launch {
            repository.updateDealStage(dealId, nextStage, contact, value, _selectedUnitId.value)
        }
    }

    fun deleteDeal(dealId: Int) {
        viewModelScope.launch {
            repository.deleteDeal(dealId, _selectedUnitId.value)
        }
    }

    fun processPayroll(employeeId: Int, name: String, salary: Double, allowance: Double, deduction: Double) {
        viewModelScope.launch {
            val net = salary + allowance - deduction
            val monthYear = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date())
            val payroll = Payroll(
                employeeId = employeeId,
                monthYear = monthYear,
                salary = salary,
                allowance = allowance,
                deduction = deduction,
                netSalary = net,
                status = "DIBAYAR"
            )
            repository.processPayroll(payroll, name, _selectedUnitId.value)
        }
    }

    fun addCustomer(name: String, email: String, phone: String) {
        viewModelScope.launch {
            repository.insertCustomer(
                PosCustomer(
                    unitId = _selectedUnitId.value,
                    namaCustomer = name,
                    email = email,
                    telepon = phone
                )
            )
            repository.logAction(
                unitId = _selectedUnitId.value,
                pesan = "Customer POS ditambahkan: $name",
                tipe = "SUCCESS",
                kategori = "POS"
            )
        }
    }

    init {
        // Initialize sample data on start
        viewModelScope.launch {
            repository.seedDatabaseIfEmpty()
        }
        _suppliers.value = listOf(
            Supplier("sup1", "CV Sinar Logistik Nusantara", "Budi Wijaya", "08123456789", "budi@sinarlogistik.co.id", "Sembako & Bahan Pokok", "Sleman, D.I. Yogyakarta"),
            Supplier("sup2", "PT Indo Distribusi Pangan", "Siti Rahma", "08567891234", "siti@indodistribusi.co.id", "Makanan & Minuman", "Cengkareng, Jakarta Barat"),
            Supplier("sup3", "CV Tekno Retail Abadi", "Fandi Ahmad", "08213579246", "fandi@teknoretail.co.id", "Perlengkapan & Kemasan", "Rungkut, Surabaya")
        )
        _purchaseOrders.value = listOf(
            PurchaseOrder("po1", "PO-2026-001", "sup1", "CV Sinar Logistik Nusantara", "Kopi Robusta Lampung 1kg", "prod_1", 20, 45000.0, 900000.0, System.currentTimeMillis() - 86400000 * 2, "SENT"),
            PurchaseOrder("po2", "PO-2026-002", "sup2", "PT Indo Distribusi Pangan", "Susu Full Cream UHT 1L", "prod_2", 15, 14000.0, 210000.0, System.currentTimeMillis() - 86400000 * 5, "RECEIVED")
        )
    }
}
